function hack() {

}